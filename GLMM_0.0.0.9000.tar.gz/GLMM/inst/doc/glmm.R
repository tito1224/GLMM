## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  warning = FALSE,
  message = FALSE
)

## ----setup, message=F---------------------------------------------------------
#load necessary libraries
library(GLMM)
library(dplyr)
library(ggplot2)

## ----echo=FALSE---------------------------------------------------------------
head(epilepsy, 10)

## ---- echo=FALSE--------------------------------------------------------------
summary(epilepsy)

## -----------------------------------------------------------------------------
epilepsyRaw <- read.csv("epilepsy.csv")
head(epilepsyRaw,10)

## ----data cleaning------------------------------------------------------------
epilepsyClean <- epilepsyRaw %>%
  group_by(id,treat,expind,age) %>%
  summarize(seizures = sum(seizures),
            .groups = "drop")

## ----str, echo=FALSE----------------------------------------------------------
str(epilepsy)

## ----factor-------------------------------------------------------------------
epilepsy$treat <- as.factor(epilepsy$treat)
epilepsy$expind <- as.factor(epilepsy$expind)

## ----plot1, echo=FALSE--------------------------------------------------------
ggplot(epilepsy, aes(x=seizures, color=treat)) + geom_density(alpha=0.5, position="identity") + facet_wrap(~expind) + ggtitle("Number of Seizures for Baseline and Trial Groups")+ theme_light()

## ---- echo=FALSE--------------------------------------------------------------
epilepsy[epilepsy$id==49,]

## ----central measures, echo=FALSE---------------------------------------------
epilepsy%>%
  group_by(expind,treat)%>%
  summarise(Mean = mean(seizures),
            Median = median(seizures),
            SD = sd(seizures))

## ----plot2, echo=FALSE--------------------------------------------------------
ggplot(epilepsy, aes(x = treat, y=seizures, color=treat)) + geom_boxplot(alpha=0.5, position="identity") + facet_wrap(~expind) + ggtitle("Number of Seizures for Baseline and Trial Groups") + theme_light()

## ----fit----------------------------------------------------------------------
epilepsy$treat <- as.numeric(epilepsy$treat)
epilepsy$expind <- as.numeric(epilepsy$expind)
epilepsy_fit <- run_model(epilepsy, "epilepsy")

## ----point est----------------------------------------------------------------
epilepsy_fit$beta #output beta estimates
epilepsy_fit$sigmasq #output sigma estimate

## ----btsp---------------------------------------------------------------------
btsp(epilepsy, example="epilepsy", B=100, seed=23)

## ----ci-----------------------------------------------------------------------
ci(epilepsy, example="epilepsy", B=100, seed=23)

## ----crit value---------------------------------------------------------------
qt(p=.05, df=58, lower.tail=T)

## ----test stats---------------------------------------------------------------
epilepsy_fit$test_stat[4]

